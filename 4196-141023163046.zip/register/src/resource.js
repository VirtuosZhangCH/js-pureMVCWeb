var res = {
    background_png: "res/background.jpg",
    map_png:"res/map.png",
    line_png:"res/line.png",
    firstPage_png: "res/firstPage.png",
    firstPage_plist: "res/firstPage.plist",
    secondPage_png: "res/secondPage.png",
    secondPage_plist: "res/secondPage.plist",
    thirdPage_png: "res/thirdPage.png",
    thirdPage_plist: "res/thirdPage.plist",
    forthPage_png: "res/forthPage.png",
    forthPage_plist: "res/forthPage.plist",
    fifPage_png: "res/fifthPage.png",
    fifPage_plist: "res/fifthPage.plist"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}